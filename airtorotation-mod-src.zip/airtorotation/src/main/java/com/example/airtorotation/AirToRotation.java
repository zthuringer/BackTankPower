package com.example.airtorotation;

import com.example.airtorotation.init.ModBlockEntities;
import com.example.airtorotation.init.ModBlocks;
import com.example.airtorotation.init.ModItems;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(AirToRotation.MODID)
public class AirToRotation {

    public static final String MODID = "airtorotation";

    public AirToRotation(IEventBus modEventBus) {
        ModBlocks.register(modEventBus);
        ModItems.register(modEventBus);
        ModBlockEntities.register(modEventBus);
    }
}
