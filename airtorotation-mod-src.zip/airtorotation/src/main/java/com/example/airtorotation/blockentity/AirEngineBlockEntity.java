package com.example.airtorotation.blockentity;

import com.example.airtorotation.block.AirEngineBlock;
import com.example.airtorotation.init.ModBlockEntities;
import com.simibubi.create.content.equipment.backtank.BacktankUtil;
import com.simibubi.create.content.kinetics.base.GeneratingKineticBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

/**
 * AirEngineBlockEntity
 *
 * Every tick this entity:
 *   1. Scans all six neighbouring inventory slots for an item that has Backtank air
 *      (using Create's BacktankUtil.hasAirRemaining / BacktankUtil.consumeAir).
 *   2. If air is available it consumes AIR_PER_TICK units and continues running.
 *   3. It extends GeneratingKineticBlockEntity so it publishes a speed via
 *      getGeneratedSpeed() – Create handles propagating that to the network.
 *
 * Tuning constants (change to taste):
 *   AIR_PER_TICK  – how much backtank air (in "units") is consumed per tick
 *   BASE_SPEED    – rotations per minute produced while air is available
 */
public class AirEngineBlockEntity extends GeneratingKineticBlockEntity {

    // ── Tuning ───────────────────────────────────────────────────────────────────

    /** Air consumed per game tick while running. BacktankUtil uses a 0-1600 scale per tank. */
    private static final int AIR_PER_TICK = 2;

    /** Rotational speed (RPM) the engine produces when air is available. */
    private static final float BASE_SPEED = 64f;

    // ── State ────────────────────────────────────────────────────────────────────

    /** Whether the engine had air last tick (used to trigger network updates). */
    private boolean wasRunning = false;

    /** The inventory-holding neighbour block entity we are currently draining. */
    private net.minecraft.world.level.block.entity.BlockEntity cachedNeighbour = null;

    // ── Constructor ──────────────────────────────────────────────────────────────

    public AirEngineBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
        setLazyTickRate(20); // lazy scan every second is fine
    }

    // ── GeneratingKineticBlockEntity ─────────────────────────────────────────────

    /**
     * Called by Create every tick to know how fast this generator is spinning.
     * Return 0 when we have no air; the network automatically stalls.
     */
    @Override
    public float getGeneratedSpeed() {
        if (!hasAirAvailable()) return 0;
        // Reverse for one shaft direction based on facing
        BlockState state = getBlockState();
        if (state.getBlock() instanceof AirEngineBlock) {
            Direction facing = state.getValue(AirEngineBlock.FACING);
            // Negative speed flips the rotation for the "back" side – purely cosmetic
            return facing.getAxisDirection() == Direction.AxisDirection.POSITIVE
                    ? BASE_SPEED : -BASE_SPEED;
        }
        return BASE_SPEED;
    }

    // ── Tick ─────────────────────────────────────────────────────────────────────

    @Override
    public void tick() {
        super.tick();
        if (level == null || level.isClientSide) return;

        boolean running = consumeAirFromNeighbour();

        if (running != wasRunning) {
            wasRunning = running;
            // Tell Create the generator speed changed so it re-propagates the network
            updateGeneratedRotation();
        }
    }

    /** Lazy tick: invalidate cached neighbour so we re-scan. */
    @Override
    public void lazyTick() {
        super.lazyTick();
        cachedNeighbour = null;
    }

    // ── Air Logic ────────────────────────────────────────────────────────────────

    /**
     * Try to drain AIR_PER_TICK units from a neighbouring Backtank item.
     *
     * Create's BacktankUtil exposes:
     *   BacktankUtil.hasAirRemaining(ItemStack)   – checks the item has > 0 air
     *   BacktankUtil.consumeAir(ItemStack, int)   – drains air from the item NBT
     *
     * We look for backtank items in neighbouring block inventories (e.g. a chest
     * or the Backtank block itself placed next to us).
     */
    private boolean consumeAirFromNeighbour() {
        if (level == null) return false;

        for (Direction dir : Direction.values()) {
            BlockPos neighbourPos = worldPosition.relative(dir);
            ItemStack backtankStack = findBacktankInNeighbour(neighbourPos);
            if (backtankStack == null || backtankStack.isEmpty()) continue;

            if (BacktankUtil.hasAirRemaining(backtankStack)) {
                BacktankUtil.consumeAir(null, backtankStack, AIR_PER_TICK);
                // Mark the neighbour dirty so its NBT is saved
                net.minecraft.world.level.block.entity.BlockEntity be =
                        level.getBlockEntity(neighbourPos);
                if (be != null) be.setChanged();
                return true;
            }
        }
        return false;
    }

    /**
     * Check whether air is available without consuming it (used by getGeneratedSpeed).
     */
    private boolean hasAirAvailable() {
        if (level == null) return false;
        for (Direction dir : Direction.values()) {
            ItemStack stack = findBacktankInNeighbour(worldPosition.relative(dir));
            if (stack != null && !stack.isEmpty() && BacktankUtil.hasAirRemaining(stack))
                return true;
        }
        return false;
    }

    /**
     * Find the first Backtank item stack in the inventory of the neighbour at pos.
     * Checks IItemHandler capability and also the raw block-entity slot 0 as fallback.
     */
    private ItemStack findBacktankInNeighbour(BlockPos pos) {
        if (level == null) return null;
        net.minecraft.world.level.block.entity.BlockEntity be = level.getBlockEntity(pos);
        if (be == null) return null;

        // NeoForge capability approach
        be.getCapability(net.neoforged.neoforge.capabilities.Capabilities.ItemHandler.BLOCK,
                // The side facing this engine
                worldPosition.relative(Direction.DOWN) // placeholder; replaced below
        );

        // Try all sides of the neighbour facing our engine for an item handler
        for (Direction capSide : Direction.values()) {
            var handler = level.getCapability(
                    net.neoforged.neoforge.capabilities.Capabilities.ItemHandler.BLOCK,
                    pos, capSide);
            if (handler == null) continue;

            for (int i = 0; i < handler.getSlots(); i++) {
                ItemStack stack = handler.getStackInSlot(i);
                if (!stack.isEmpty() && BacktankUtil.isBacktank(stack)) {
                    return stack;
                }
            }
        }
        return null;
    }

    // ── Player Interaction ───────────────────────────────────────────────────────

    public InteractionResult onPlayerInteract(Player player, InteractionHand hand) {
        if (level == null || level.isClientSide) return InteractionResult.SUCCESS;

        float speed = getGeneratedSpeed();
        boolean running = Math.abs(speed) > 0.01f;
        String status = running
                ? "§aRunning at §e" + (int) Math.abs(speed) + " RPM"
                : "§cNo air available in adjacent Backtank";
        player.sendSystemMessage(Component.literal("[Air Engine] " + status));
        return InteractionResult.SUCCESS;
    }

    // ── NBT ──────────────────────────────────────────────────────────────────────

    @Override
    protected void write(CompoundTag tag, boolean clientPacket) {
        super.write(tag, clientPacket);
        tag.putBoolean("WasRunning", wasRunning);
    }

    @Override
    protected void read(CompoundTag tag, boolean clientPacket) {
        super.read(tag, clientPacket);
        wasRunning = tag.getBoolean("WasRunning");
    }
}
