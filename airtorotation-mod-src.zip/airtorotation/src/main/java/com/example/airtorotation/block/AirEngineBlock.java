package com.example.airtorotation.block;

import com.example.airtorotation.blockentity.AirEngineBlockEntity;
import com.example.airtorotation.init.ModBlockEntities;
import com.simibubi.create.content.kinetics.base.KineticBlock;
import com.simibubi.create.foundation.block.IBE;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Air Engine Block
 *
 * Place this block adjacent to a Backtank (or any inventory containing a Backtank
 * as an item).  The block entity will drain air from the Backtank each tick and
 * convert it into rotational power via Create's KineticBlock system.
 *
 * Rotation axis: the block faces in a direction (FACING property).
 * The shaft axis is the axis of that direction (e.g. NORTH/SOUTH → Z axis).
 */
public class AirEngineBlock extends KineticBlock implements IBE<AirEngineBlockEntity> {

    public static final DirectionProperty FACING = BlockStateProperties.FACING;

    public AirEngineBlock(Properties properties) {
        super(properties);
        registerDefaultState(defaultBlockState().setValue(FACING, Direction.NORTH));
    }

    // ── Block State ──────────────────────────────────────────────────────────────

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        // Face away from the player so the shaft points toward whatever they clicked
        Direction facing = context.getNearestLookingDirection().getOpposite();
        return defaultBlockState().setValue(FACING, facing);
    }

    // ── Kinetic (Create) ─────────────────────────────────────────────────────────

    /**
     * The shaft of this block runs along the axis of its FACING direction.
     * For example, FACING=NORTH → axis=Z.
     */
    @Override
    public Direction.Axis getRotationAxis(BlockState state) {
        return state.getValue(FACING).getAxis();
    }

    /**
     * The engine produces its own speed, so it does not need to receive rotation
     * from a neighbor.  Returning false on all sides means other kinetic blocks
     * won't try to "feed" us rotation; we publish ours instead.
     */
    @Override
    public boolean hasShaftTowards(Level world, BlockPos pos, BlockState state, Direction face) {
        // Expose shaft on both ends of our rotation axis
        Direction facing = state.getValue(FACING);
        return face == facing || face == facing.getOpposite();
    }

    // ── Block Entity ─────────────────────────────────────────────────────────────

    @Override
    public Class<AirEngineBlockEntity> getBlockEntityClass() {
        return AirEngineBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends AirEngineBlockEntity> getBlockEntityType() {
        return ModBlockEntities.AIR_ENGINE.get();
    }

    // ── Interaction ──────────────────────────────────────────────────────────────

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos,
                                 Player player, InteractionHand hand, BlockHitResult hit) {
        // Let the block entity handle right-click (shows status via chat / actionbar)
        return onBlockEntityUse(level, pos, be -> be.onPlayerInteract(player, hand));
    }

    // ── Misc ─────────────────────────────────────────────────────────────────────

    @Override
    public boolean isPathfindable(BlockState state, BlockGetter level, BlockPos pos,
                                  net.minecraft.world.level.pathfinder.PathComputationType type) {
        return false;
    }
}
