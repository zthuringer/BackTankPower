# Air To Rotation — NeoForge 1.21.1 Mod

Converts **Create's Backtank compressed air** into **rotational power**.

## How It Works

Place the **Air Engine** block adjacent to any inventory that holds a
Backtank item (chests, the Backtank block itself, barrels, etc.).

Each game tick the engine drains a small amount of air from the
nearest Backtank it can find and converts that into **64 RPM** of
rotational force — compatible with any other Create machinery.

Right-click the block to see its current RPM and whether a Backtank
is detected.

## Tuning (AirEngineBlockEntity.java)

| Constant       | Default | Meaning                                      |
|----------------|---------|----------------------------------------------|
| `AIR_PER_TICK` | `2`     | Backtank air units consumed per game tick    |
| `BASE_SPEED`   | `64f`   | RPM output while air is available            |

## Setup

### 1. Generate textures (first time only)
```
pip install Pillow
python generate_textures.py
```

### 2. Check Create version
Confirm your Create for NeoForge version in `build.gradle`:
```
implementation "com.simibubi.create:create-1.21.1:6.0.4:slim"
```
Check https://www.curseforge.com/minecraft/mc-mods/create-for-neoforge for latest.

### 3. Build
```
./gradlew build
```
The output JAR lands in `build/libs/`.

## Mod Dependencies

| Mod          | Version  |
|--------------|----------|
| NeoForge     | 21.1.x   |
| Create       | 6.0+     |
| Flywheel     | 1.0+     |

## File Structure

```
src/main/java/com/example/airtorotation/
├── AirToRotation.java                  ← Mod entry point
├── block/
│   └── AirEngineBlock.java             ← Block (extends KineticBlock)
├── blockentity/
│   └── AirEngineBlockEntity.java       ← Drains air, outputs RPM
└── init/
    ├── ModBlocks.java
    ├── ModItems.java
    └── ModBlockEntities.java

src/main/resources/
├── META-INF/mods.toml
├── assets/airtorotation/
│   ├── blockstates/air_engine.json
│   ├── lang/en_us.json
│   ├── models/block/air_engine.json
│   ├── models/item/air_engine.json
│   └── textures/block/
│       ├── air_engine_side.png
│       └── air_engine_front.png
└── pack.mcmeta
```

## Recipe (add to data/airtorotation/recipes/air_engine.json)

```json
{
  "type": "minecraft:crafting_shaped",
  "pattern": ["IPI", "PCP", "IPI"],
  "key": {
    "I": { "item": "minecraft:iron_ingot" },
    "P": { "item": "create:copper_casing" },
    "C": { "item": "create:cogwheel" }
  },
  "result": { "item": "airtorotation:air_engine", "count": 1 }
}
```
