"""
generate_textures.py
Run once to create the Air Engine block textures as 16×16 PNGs.
Requires Pillow: pip install Pillow
Output goes to:  src/main/resources/assets/airtorotation/textures/block/
"""

from PIL import Image, ImageDraw
import os

OUT = "src/main/resources/assets/airtorotation/textures/block"
os.makedirs(OUT, exist_ok=True)

# ── Palette ──────────────────────────────────────────────────────────────────
DARK   = (40,  40,  50,  255)   # dark metal frame
MID    = (80,  85,  95,  255)   # mid metal
LIGHT  = (130, 135, 145, 255)   # highlight
CYAN   = (80,  200, 220, 255)   # air / blue accent
YELLOW = (230, 180, 30,  255)   # brass bolt

def make_side(size=16):
    img = Image.new("RGBA", (size, size), MID)
    d   = ImageDraw.Draw(img)
    # border
    d.rectangle([0,0,size-1,size-1], outline=DARK)
    # corner bolts
    for cx, cy in [(2,2),(13,2),(2,13),(13,13)]:
        d.point([(cx,cy)], fill=YELLOW)
    # centre panel
    d.rectangle([4,4,11,11], fill=DARK, outline=LIGHT)
    # shaft hole
    d.ellipse([6,6,9,9], fill=CYAN, outline=DARK)
    return img

def make_front(size=16):
    img = Image.new("RGBA", (size, size), DARK)
    d   = ImageDraw.Draw(img)
    # outer ring
    d.ellipse([1,1,14,14], outline=LIGHT)
    # inner air spiral (simplified as concentric arcs)
    d.ellipse([3,3,12,12], outline=CYAN)
    d.ellipse([5,5,10,10], outline=CYAN)
    # shaft
    d.ellipse([6,6,9,9],   fill=LIGHT, outline=DARK)
    # corner bolts
    for cx, cy in [(1,1),(14,1),(1,14),(14,14)]:
        d.rectangle([cx,cy,cx+1,cy+1], fill=YELLOW)
    return img

make_side().save(os.path.join(OUT, "air_engine_side.png"))
make_front().save(os.path.join(OUT, "air_engine_front.png"))
print("Textures generated in", OUT)
