package com.example.airtorotation.init;

import com.example.airtorotation.AirToRotation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {

    public static final DeferredRegister.Items ITEMS =
            DeferredRegister.createItems(AirToRotation.MODID);

    public static final DeferredItem<BlockItem> AIR_ENGINE =
            ITEMS.register("air_engine", () ->
                    new BlockItem(ModBlocks.AIR_ENGINE.get(), new Item.Properties()));

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}
