package com.example.airtorotation.init;

import com.example.airtorotation.AirToRotation;
import com.example.airtorotation.blockentity.AirEngineBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.minecraft.core.registries.Registries;

public class ModBlockEntities {

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, AirToRotation.MODID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AirEngineBlockEntity>> AIR_ENGINE =
            BLOCK_ENTITIES.register("air_engine", () ->
                    BlockEntityType.Builder.of(AirEngineBlockEntity::new, ModBlocks.AIR_ENGINE.get())
                            .build(null));

    public static void register(IEventBus eventBus) {
        BLOCK_ENTITIES.register(eventBus);
    }
}
